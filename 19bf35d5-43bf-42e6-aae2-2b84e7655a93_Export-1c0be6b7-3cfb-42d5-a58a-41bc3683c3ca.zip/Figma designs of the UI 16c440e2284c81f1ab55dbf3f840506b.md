# Figma designs of the UI

Status: Complete
Stage: Foundational Setup (Foundational%20Setup%2016c440e2284c81eabb86fc13296bc471.md)
From: September 8, 2020
To: September 12, 2020
Days Until Due: -1773