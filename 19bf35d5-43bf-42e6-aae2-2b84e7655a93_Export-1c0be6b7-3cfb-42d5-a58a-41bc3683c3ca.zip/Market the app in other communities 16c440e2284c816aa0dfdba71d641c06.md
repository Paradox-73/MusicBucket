# Market the app in other communities

Status: Complete
Stage: Final Polish (Final%20Polish%2016c440e2284c8195b135f1926510af91.md)
From: November 14, 2020
To: November 19, 2020
Days Until Due: -1705