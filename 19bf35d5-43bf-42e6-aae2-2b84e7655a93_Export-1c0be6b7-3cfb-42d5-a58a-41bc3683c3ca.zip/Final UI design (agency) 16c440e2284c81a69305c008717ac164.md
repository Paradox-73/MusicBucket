# Final UI design (agency)

Status: Complete
Stage: Design the apps user interface (Design%20the%20apps%20user%20interface%2016c440e2284c81acb7e4e8ce04003a5f.md)
From: September 22, 2020
To: October 14, 2020
Days Until Due: -1741