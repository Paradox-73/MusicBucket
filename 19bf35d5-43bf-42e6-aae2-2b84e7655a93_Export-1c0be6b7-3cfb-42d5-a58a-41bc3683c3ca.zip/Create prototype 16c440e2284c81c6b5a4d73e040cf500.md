# Create prototype

Status: Complete
Stage: Foundational Setup (Foundational%20Setup%2016c440e2284c81eabb86fc13296bc471.md)
From: September 17, 2020
To: September 22, 2020
Days Until Due: -1763