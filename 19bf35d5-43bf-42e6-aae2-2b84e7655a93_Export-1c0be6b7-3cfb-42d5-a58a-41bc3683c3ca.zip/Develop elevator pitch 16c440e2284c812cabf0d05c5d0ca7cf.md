# Develop elevator pitch

Status: Complete
From: August 15, 2020
To: August 15, 2020
Days Until Due: -1801