# Pencil sketches of the UI

Status: Complete
Stage: Foundational Setup (Foundational%20Setup%2016c440e2284c81eabb86fc13296bc471.md)
From: September 2, 2020
To: September 5, 2020
Days Until Due: -1780