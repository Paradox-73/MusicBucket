# Announce app launch

Status: Delayed
Stage: Launch (Launch%2016c440e2284c81919beddb879885562e.md)
From: November 21, 2020
To: November 21, 2020
Days Until Due: -1703