# Collect user feedback

Status: Not Started
Stage: Improve the app based on user feedback (Improve%20the%20app%20based%20on%20user%20feedback%2016c440e2284c81fbb5b6c46a66a4d2cd.md)
From: November 28, 2020
To: December 26, 2020
Days Until Due: -1668