# Review most similar apps

Status: In Progress
Stage: Carry out competitive market research (Carry%20out%20competitive%20market%20research%2016c440e2284c81d68272f19b3075ca23.md)
From: January 11, 2025
To: January 20, 2025
Days Until Due: -182

1. https://www.obscurifymusic.com/home
- Can cross check the popularity stats. Most obscure tracks and artists.
- Can use metrics like Happiness, Danceability, Energy, and Acousticness.
- Features like By the Decades, Share with your friends, recommendations.
- No online repo.

1. https://icebergify.com/
- Create Icebergs based on the popularity, and time of artists, tracks, genres, and albums.
- Can use it for artist depth to show the popularity of songs that user has listened.
- No online repo.

1. https://stats.fm/
- More of a mobile app.
- https://github.com/statsfm

1. https://huangdarren1106.github.io/spotify-stats

![image.png](image.png)

![image.png](image%201.png)

![image.png](image%202.png)

- Show the artist with the genre.
- Data visualization with pie, bubbles, receipts, etc.
- MusicPieChart.
- Lyrics can be powered by genius.

1. https://volt.fm/

Best UI/UX. Literally, try to copy as much as possible.

![image.png](image%203.png)

1. https://ngenart.com/

Data Poster

![image.png](image%204.png)

DNA

![image.png](image%205.png)

Persona

![image.png](image%206.png)

Timeline

1. https://receiptify.herokuapp.com/

See portfolio of person who made it.

[https://github.com/michellexliu/receiptify](https://github.com/michellexliu/receiptify)

1. https://musictaste.space/home
- Most creative UI and a way to keep user keep on the site.
- Sonic collage on artworks of music you are listening to right now.
- Compare tests. (better blend)
- Sound Aura-musical aura is calculated based on Spotify API data for your top artists and tracks from the last few weeks. Incorporating information such as the danceability, happiness, tempo, and a variety of other data points, the result is a one-of-a-kind aura and a unique title and description. This gradient will only appear for you. A new aura can be computed every seven days.
- Discord server.

1. https://www.instafest.app/home
- Concert fest like artists performing image. Also has basic score to cross-check.

1.  https://discoverquickly.com/
- Best website for discovery.
- **Start anywhere**, depending on your mood: music you already love, today's top hits, or something random. Then **hover over images** to sample tracks immediately. If you maybe like what you hear, then click to follow your ears down the rabbit hole of your musical taste. **Save, follow, or playlist** anything you like. If you're a Spotify subscriber, you can listen to full tracks from this page, but we see this mainly as your curation tool. It's your supercharged record shop for browsing: collect stuff you might like, and then listen deeply later.

![image.png](image%207.png)

1.  https://trackify.am/dashboard/simple
- Stats.

1.  https://spotalike.com/en
- Creates playlist based on song.
- Can click on a song in the generated playlist to find songs similar to that song. (Rabbit hole) can share, shows around 50 songs (can ask how many songs user wants)

1.  https://magicplaylist.co/
- Creates playlist based on songs
- User can add own name, private/public, “let me tweak”, refresh, add, play at same time. Image option too. Sequencing of playlist.

1.  https://dubolt.com/
- Creates playlist based on artist
- Better ui. Track list settings. Has info on creator.

1.  http://www.playlistmachinery.com/
- BoilTheFrog - Creates a playlist between any two artists (can increase to include more)
- Smarter playlist- combine sources such as artist albums excusing graph ui.
- Organise music-based on musical attributes.
- Playlist Miner - makes playlist from top tracks in most popular public playlist.
- Road trip mixtape- local artists from the road you take.

1.  https://predominant.ly/
- Suggest albums based on cover art colour

1.  https://www.gnod.com/
- Music map Gnoosic
- Suggests similar artists And songs.

1.  https://www.chosic.com/
- Download music. Number 1 song on your birthday (define region, music videos, make playlist from birth to last bday). Blog posts,
1.  https://musicoveryb2b.mystrikingly.com/
- **Rich Metadata:**
    - **Tracks:** Genres, moods (keywords & quantitative values like valence/arousal), acoustic descriptors.
    - **Artists:** Genres, era, role, geographic location.
- **Personalized Recommendations:**
    - **Real-time:** Tailored playlists and tracks based on user preferences.
    - **Diverse Options:** Recommendations for live concerts, playlists, YouTube channels.
- **Bespoke Webservices:**
    - **Customizable content delivery:** Enables integration with other platforms.
- **Expert Guidance:**
    - **Data Analysis:** Advice on optimizing recommendation algorithms.
    - **Metadata Sourcing:** Strategies for acquiring and managing music data.
    - **Music UX Design:** Insights into creating user-friendly music experiences.
- **Activity-Based Recommendations:**
    - **Contextual listening:** Music suggestions for driving, working, partying, etc.
1.  https://www.liveplasma.com/index.php

graph based discovery engine. Inspo for ui

1.  https://github.com/cjstewart88/tubalr/

GitHub repo

1.  https://github.com/andreskrey/tothebestof

GitHub repo

1.   https://tastedive.com/

Recommends based on what you search. Also has API. 

1. https://www.reddit.com/r/spotify/s/jg8ZyD1u3w