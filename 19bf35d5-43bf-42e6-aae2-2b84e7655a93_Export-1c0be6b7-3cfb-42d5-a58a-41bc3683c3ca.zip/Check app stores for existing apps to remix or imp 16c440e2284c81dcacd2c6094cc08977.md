# Check app stores for existing apps to remix or improve

Status: Complete
From: August 5, 2020
To: August 7, 2020
Days Until Due: -1809