# Email pre-launch list

Status: Complete
Stage: Final Polish (Final%20Polish%2016c440e2284c8195b135f1926510af91.md)
From: November 11, 2020
To: November 13, 2020
Days Until Due: -1711