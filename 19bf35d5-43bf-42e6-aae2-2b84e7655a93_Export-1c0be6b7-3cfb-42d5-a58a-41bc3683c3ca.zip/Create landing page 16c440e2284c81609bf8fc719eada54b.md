# Create landing page

Status: Complete
Stage: Final Polish (Final%20Polish%2016c440e2284c8195b135f1926510af91.md)
From: October 15, 2020
To: October 17, 2020
Days Until Due: -1738