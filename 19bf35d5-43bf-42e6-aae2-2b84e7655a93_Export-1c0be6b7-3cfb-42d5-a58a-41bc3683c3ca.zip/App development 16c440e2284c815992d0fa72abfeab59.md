# App development

Status: Complete
Stage: Build the app (Build%20the%20app%2016c440e2284c81c181fec85862af0100.md)
From: October 15, 2020
To: November 19, 2020
Days Until Due: -1705

1. **Overall**
    - Share your liked songs (make a new playlist)
    - UI/UX rework
    - Dark mode toggle
    - Authentication and Database
    - Save the page data when switching from one page to another
    - footer generate unique facts
    - Monthly email newsletter of diff in stats, reminder of bucketlist, etc
    - roast me
    - make custom playlist from your liked songs/or not based on given prompt/menu
    - comment
    - make better readme
    - find sample of the song

1. **Homepage/Dashboard**
    - After landing and login, should show stats
    - Basically make exploration score the homepage with other stats
2. **Artist Exploration**
    - work around to calculate exploration for each unique artist in liked songs ()
    - Fix the algo to calculate the score
3. **Bucket List**
    - Fix search filter
4. **Culture Clash**
    - globe doesn't spin
    - no idea on how to get and present data from each country
5. **Exploration Score**
    - better intensive stats and visualization
    - fix algo to make score
6. **Rabbit Hole**
    - make the entire thing
7. **Recommendation Roulette**
    - fix filter
    - maybe can tinder like interface cause spinning isn't interesting
    - remove header footer
8. **Roadtrip Mixtape**
    - see solution for real time traffic
    - make playlist on local artist/popular artist/from your liked songs
    - can listen to each song on site, add remove, see album art, give pic,
9. **Music Personality**
    - make the entire thing
10. **About Us**
    - individual pic, better bio
11. **Support**
    - kofi doesn't wok find alt
    - can make subreddit/discord server etc
12. **Legal**
    - see other for what have to do